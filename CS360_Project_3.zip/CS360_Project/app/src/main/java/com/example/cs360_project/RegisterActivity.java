package com.example.cs360_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    Button buttonAddUser, buttonExitRegister;
    EditText newNameText, newPassText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        buttonAddUser = findViewById(R.id.buttonAddUser);
        buttonExitRegister = findViewById(R.id.buttonExitRegister);

        newNameText = findViewById(R.id.newNameText);
        newPassText = findViewById(R.id.newPassText);

        buttonExitRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();

            }
        });

        buttonAddUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                UserDatabase userDatabase = new UserDatabase(RegisterActivity.this);

                UserModel userModel = null;

                if (newNameText.getText().toString().equals("") || newPassText.getText().toString().equals("")) {
                    Toast.makeText(RegisterActivity.this, "Please enter Credentials", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        userModel = new UserModel(-1, newNameText.getText().toString(), newPassText.getText().toString());
                        Toast.makeText(RegisterActivity.this, userModel.toString(), Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(RegisterActivity.this, "Error Registering User", Toast.LENGTH_SHORT).show();
                    }

                    boolean success = userDatabase.addOne(userModel);

                    Toast.makeText(RegisterActivity.this, "Success: " + success, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}