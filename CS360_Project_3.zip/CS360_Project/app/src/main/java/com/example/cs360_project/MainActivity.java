package com.example.cs360_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Reference to buttons and other controls
    Button buttonSignIn, buttonRegister, buttonSettings, buttonAdd, buttonAddData, buttonExitNewData, buttonExitSettings, buttonSignOut, buttonAddUser, buttonExitRegister;
    EditText nameText, passText, itemNameText, descriptionText, quantityText, newNameText, newPassText;
    CheckBox checkBoxSMSNotif;
    GridView gridItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonSignIn = findViewById(R.id.buttonSignIn);
        buttonRegister = findViewById(R.id.buttonRegister);
        buttonSettings = findViewById(R.id.buttonSettings);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonAddData = findViewById(R.id.buttonAddData);
        buttonExitNewData = findViewById(R.id.buttonExitNewData);
        buttonExitSettings = findViewById(R.id.buttonExitSettings);
        buttonSignOut = findViewById(R.id.buttonSignOut);
        buttonAddUser = findViewById(R.id.buttonAddUser);
        buttonExitRegister = findViewById(R.id.buttonExitRegister);

        nameText = findViewById(R.id.nameText);
        passText = findViewById(R.id.passText);
        itemNameText = findViewById(R.id.itemNameText);
        descriptionText = findViewById(R.id.descriptionText);
        quantityText = findViewById(R.id.quantityText);
        newNameText = findViewById(R.id.newNameText);
        newPassText = findViewById(R.id.newPassText);

        checkBoxSMSNotif = findViewById(R.id.checkBoxSMSNotif);
        gridItem = findViewById(R.id.gridItem);

        //Button Listeners

        buttonSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                UserDatabase userDatabase = new UserDatabase(MainActivity.this);

                UserModel userModel = null;

                if (nameText.getText().toString().equals("") || passText.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, "Please enter Credentials", Toast.LENGTH_SHORT).show();
                }
                else{
                    try {
                        userModel = new UserModel(-1, nameText.getText().toString(), passText.getText().toString());
                    }
                    catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Error Signing User In", Toast.LENGTH_SHORT).show();
                    }

                    boolean success = userDatabase.checkCredentials(userModel);
                    if (success == true) {
                        Intent intent = new Intent(getApplicationContext(), ViewDatabaseActivity.class);
                        startActivity(intent);

                    }
                    else{
                        Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }

                    Toast.makeText(MainActivity.this, "Success: " + success, Toast.LENGTH_SHORT).show();
                }



            }
        });

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(MainActivity.this, RegisterActivity.class));

            }
        });


    }
}