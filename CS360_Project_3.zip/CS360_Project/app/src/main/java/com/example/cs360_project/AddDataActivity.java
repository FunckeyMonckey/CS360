package com.example.cs360_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddDataActivity extends AppCompatActivity {

    Button buttonAddData, buttonExitNewData;
    EditText itemNameText, descriptionText, quantityText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_data_popout);

        buttonAddData = findViewById(R.id.buttonAddData);
        buttonExitNewData = findViewById(R.id.buttonExitNewData);
        itemNameText = findViewById(R.id.itemNameText);
        descriptionText = findViewById(R.id.descriptionText);
        quantityText = findViewById(R.id.quantityText);

        buttonExitNewData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        buttonAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ItemDatabase itemDatabase = new ItemDatabase(AddDataActivity.this);

                ItemModel itemModel = null;

                if (itemNameText.getText().toString().equals("") || descriptionText.getText().toString().equals("") || quantityText.getText().toString().equals("")) {
                    Toast.makeText(AddDataActivity.this, "Please Fill Out Item Information", Toast.LENGTH_SHORT).show();
                }
                else {
                    try{
                        itemModel = new ItemModel(-1, itemNameText.getText().toString(), descriptionText.getText().toString(), Integer.parseInt(quantityText.getText().toString()));
                    } catch (Exception e) {
                        Toast.makeText(AddDataActivity.this, "Failed to Add Item", Toast.LENGTH_SHORT).show();
                    }

                    boolean success = itemDatabase.addItem(itemModel);

                    Toast.makeText(AddDataActivity.this, "Success: " + success, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}