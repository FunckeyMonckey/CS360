package com.example.cs360_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ScrollView;
import android.widget.Toast;

import java.util.List;

public class ViewDatabaseActivity extends AppCompatActivity {

    ItemDatabase itemDatabase;

    Button buttonSettings, buttonAdd, buttonRefresh;
    ScrollView databaseScroll;
    GridView gridItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.database);

        buttonRefresh = findViewById(R.id.buttonRefresh);
        buttonSettings = findViewById(R.id.buttonSettings);
        buttonAdd = findViewById(R.id.buttonAdd);
        databaseScroll = findViewById(R.id.databaseScroll);
        gridItem = findViewById(R.id.gridItem);

        itemDatabase = new ItemDatabase(ViewDatabaseActivity.this);

        ShowItemFromItemList(itemDatabase);

        buttonSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent (ViewDatabaseActivity.this, SettingsActivity.class));

            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ViewDatabaseActivity.this, AddDataActivity.class));

            }
        });

        buttonRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ItemDatabase itemDatabase = new ItemDatabase(ViewDatabaseActivity.this);

                ShowItemFromItemList(itemDatabase);

                //Toast.makeText(ViewDatabaseActivity.this, items.toString(), Toast.LENGTH_SHORT).show();
            }
        });

        gridItem.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                ItemModel clickedItem = (ItemModel) adapterView.getItemAtPosition(i);
                itemDatabase.deleteItem(clickedItem);
                ShowItemFromItemList(itemDatabase);
                Toast.makeText(ViewDatabaseActivity.this, "Deleted Item", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void ShowItemFromItemList(ItemDatabase itemDatabase2) {
        ArrayAdapter<ItemModel> itemArrayAdapter = new ArrayAdapter<ItemModel>(ViewDatabaseActivity.this, android.R.layout.simple_list_item_1, itemDatabase2.getAllItems());
        gridItem.setAdapter(itemArrayAdapter);
    }
}