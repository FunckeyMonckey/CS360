package com.example.cs360_project;

public class ItemModel {

    private Integer itemId;
    private String itemName;
    private String description;
    private Integer quantity;

    public ItemModel(Integer itemId, String itemName, String description, Integer quantity) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.description = description;
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "ItemModel{" +
                "id=" + itemId +
                ", name='" + itemName + '\'' +
                ", description='" + description + '\'' +
                ", quantity=" + quantity +
                '}';
    }

    public Integer getItemId() {
        return itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public String getDescription() {
        return description;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setItemId(Integer id) {
        this.itemId = id;
    }

    public void setItemName(String name) {
        this.itemName = name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}
